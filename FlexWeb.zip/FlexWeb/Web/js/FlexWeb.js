var speechSynthesis = window.speechSynthesis;
var utterance = new window.SpeechSynthesisUtterance();
utterance.lang = 'zh-TW';//未設定時Firefox錯誤
  utterance.volume = 1;//音量，0~1 ,1 是預設音量
  utterance.rate = 1; //朗讀速度0.1~10 ,1 是預設速度
  utterance.pitch = 1; //音調 0~2 ,1 是預設頻率
function speak(msg) { utterance.text=msg ; speechSynthesis.speak(utterance); }
function startup(msg) { speak(msg);
  var today = new Date();  var year = today.getFullYear();
  var month = ('0' + (today.getMonth() + 1)).slice(-2);var day = ('0' + today.getDate()).slice(-2);  
  document.getElementById('QueryDate').value =year + '-' + month + '-' + day + 'T00:00';
  document.getElementById('QueryDate2').value =year + '-' + month + '-' + day + 'T23:59';
  loadData();}
function loadData(){document.getElementById('query').click();}
function csvexport(){ csvContent=document.getElementById('myDiv').innerHTML;downloadCSV(csvContent);}
function PN_click(dd) { 
  var field = document.getElementById("QueryDate");
  var ymd = new Date(field.value); ymd.setDate(ymd.getDate()+dd); var year = ymd.getFullYear();
  var month = ('0' + (ymd.getMonth() + 1)).slice(-2);var day = ('0' + ymd.getDate()).slice(-2); 
  field.value=year+ '-' + month + '-' + day + 'T00:00';
  document.getElementById("QueryDate2").value=year + '-' + month + '-' + day + 'T23:59';
  loadData();}
function PM_click(d) { var field = document.getElementById("QueryDate");var ymd = new Date(field.value);
  if (d=='M'){ if (ymd.getMonth()<9){ms="-0"+(ymd.getMonth()+1);}else{ms="-"+(ymd.getMonth()+1);}
  field.value=ymd.getFullYear()+ms+"-01T00:00";document.getElementById("RangeSel").value=10; }
    else {field.value=ymd.getFullYear()+"-01-01T00:00"; document.getElementById("RangeSel").value=7;};
  if (d=='M') {ymd.setMonth(ymd.getMonth()+1);ymd.setDate(1);ymd.setDate(ymd.getDate()-1);}else{ymd.setMonth(11);ymd.setDate(31);}; 
    if (ymd.getMonth()<9){ms="-0"+(ymd.getMonth()+1);}else{ms="-"+(ymd.getMonth()+1);}
    document.getElementById("QueryDate2").value=ymd.getFullYear()+ms+"-"+ymd.getDate()+ 'T23:59';loadData(); }
function downloadCSV(Content) {
  let blob = new Blob([Content], { type: "text/csv;charset=utf-8;" });
  let link = document.createElement("a"); let url = URL.createObjectURL(blob);
  link.setAttribute("href", url); link.setAttribute("download", "data.csv");
  document.body.appendChild(link); link.click(); document.body.removeChild(link);}
function downloadxls(filename) {
  const link = document.createElement("a"); link.href = filename;  
  var f=filename.split('/'); link.download = f[1];
  document.body.appendChild(link);  link.click();
  document.body.removeChild(link);
  }
function printTable(tableID){
  var printContents = document.getElementById(tableID).outerHTML;
  var printWindow = window.open('', '', 'height=600,width=800');
  printWindow.document.write('<html><head><title>Print Table</title>');
  printWindow.document.write('<link rel="stylesheet" href="bootstrap/bootstrap.min.css" />'); 
  printWindow.document.write('</head><body>'); 
  printWindow.document.write(printContents); 
  printWindow.document.write('</body></html>'); 
  printWindow.document.close();printWindow.print();printWindow.close(); } 
function startupV() {  
  var today = new Date();  var year = today.getFullYear();
  var month = ('0' + (today.getMonth() + 1)).slice(-2);var day = ('0' + today.getDate()).slice(-2);  
  document.getElementById('QueryDate').value =year + '-' + month + '-' + day;
  loadData(1); }
function PN_clickV(dd) { 
  var field = document.getElementById("QueryDate");
  var ymd = new Date(field.value); ymd.setDate(ymd.getDate()+dd); 
  field.value=ymd.toISOString().slice(0, 10) ; loadData(1);}
function toPdf(pdftype) { 		
    url = "&qDate="+ document.getElementById("QueryDate").value.replace(/T/g,' ');
    url +="&qDate2="+ document.getElementById("QueryDate2").value.replace(/T/g,' ');
    if (pdftype=='Ae'){
      url+="&alarm="+document.getElementById("alarm").checked;    
      url+="&acked="+document.getElementById("acked").checked;	
      url+="&outalm="+document.getElementById("outalm").checked;	}
    if (pdftype=='Diag'){
      url+="&fError="+document.getElementById("fError").checked;    
      url+="&fWarning="+document.getElementById("fWarning").checked;	
      url+="&fInfo="+document.getElementById("fInfo").checked;	}   
    url+="&NewFirst="+document.getElementById("NewFirst").checked;	    
    url+="&filtertag="+document.getElementById("filtertag").value;
    url="/SE_"+pdftype+"PDF?filter="+document.getElementById("filter").checked+url;
    fetch(url).then(function(response){return response.text();}).then(function(resp){   
      downloadxls(resp);}); } 
function xlsData(api) {	
  url = "&qDate="+ document.getElementById("QueryDate").value.replace(/T/g,' ');
  url +="&qDate2="+ document.getElementById("QueryDate2").value.replace(/T/g,' ');
  url+='&RangeSel='+document.getElementById("RangeSel").value;	
  url='/'+api+'?Report='+document.getElementById("rep").value+url;	
  fetch(url).then(function(response){return response.text();}).then(function(resp){   
    downloadxls(resp);}); }
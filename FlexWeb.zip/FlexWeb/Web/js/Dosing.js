const buttonGroup = document.getElementById('buttonGroup');
const buttons = buttonGroup.querySelectorAll('button');     
let selectedValue = 0; var seldt;
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    buttons.forEach(b => {b.classList.remove('btn-success');b.classList.add('btn-secondary');});
      btn.classList.remove('btn-secondary'); btn.classList.add('btn-success'); 
      selectedValue = btn.getAttribute('data-value');
      if (selectedValue=="0"){document.getElementById('batchdiv').style.display = "block";}else{
        document.getElementById('batchdiv').style.display = "none";}
      if (selectedValue=="1"){document.getElementById('recipediv').style.display = "block";}else{
        document.getElementById('recipediv').style.display = "none";}
      if (selectedValue=="2"){document.getElementById('materialdiv').style.display = "block";}else{
        document.getElementById('materialdiv').style.display = "none";} 
      if (selectedValue=="3"){document.getElementById('dailydiv').style.display = "block";}else{
        document.getElementById('dailydiv').style.display = "none";} 
      if (selectedValue=="4"){document.getElementById('batcha').style.display = "block";}else{
        document.getElementById('batcha').style.display = "none";}
      if (selectedValue=="5"){document.getElementById('batchb').style.display = "block";}else{
        document.getElementById('batchb').style.display = "none";} 
      if (selectedValue=="6"){document.getElementById('batchc').style.display = "block";}else{
        document.getElementById('batchc').style.display = "none";}   
      });})
function qquery(lang) {	
  var rcpSel=""
  if (document.getElementById("rcpSelect")) {
    if (document.getElementById("filter").checked==true) rcpSel=document.getElementById("rcpSelect").value};
  document.getElementById("table").textContent="";  
  url = `/Dosing/${selectedValue}`;
  url+='?QueryDate='+document.getElementById("QueryDate").value;
  url+='&QueryDate2='+document.getElementById("QueryDate2").value;
  url+='&Lang='+lang+'&rcpSel='+rcpSel;
  htmx.ajax('GET', url, {target: '#table'});}

function printTB() {
  switch (selectedValue) {
  case "1":printTable('recipeTable');
  break;
  case "2":printTable('materialTable');
  break;
  case "3":printTable('dailyTable');
  break;
  default:printTable('batchTable');}
  }
function dailytrend() {
  trenddata=document.getElementById("trenddata").textContent;
  updateChart('A,B,C,Total',trenddata);
  trendmodal.showModal();}
function updateChart(Labels,Datas) { 
    var labels = Labels.split(',');tLen=labels.length;
    var colors = [ "blue","red","green","BlueViolet","yellow","purple","orange","Aqua","Chartreuse","Chocolate" ];
    var canvas = document.getElementById("TrendChart");
    var ctx = canvas.getContext('2d');
    const dpi = window.devicePixelRatio || 1;const displayWidth = 1200;const displayHeight = 600;
    canvas.style.width = displayWidth + "px"; canvas.style.height = displayHeight + "px";
    canvas.width = displayWidth * dpi; canvas.height = displayHeight * dpi; ctx.scale(dpi, dpi);
    if (window.trendchart) {window.trendchart.destroy(); }
    window.trendchart = new Chart(ctx, {
      type: 'line',
      data: { labels: []},
      options:{
        tooltips:{mode:'index',intersect:false},
        scales:{ yAxes:[{ display:true, 
        ticks:{min:0,suggestedMax:10} }] }}
      });
      var lines=[];for (i=0;i<tLen;i++){
        var line={label:labels[i],data: [],pointRadius:2,fill: false, borderColor: colors[i % 10], borderWidth: 1 };
        lines.push(line);window.trendchart.data.datasets.push(lines[i]);}    
        var rows = new Array(); rows = Datas.split(';');
        for(var count=0;count< rows.length-2; count++){
          var cell_data=rows[count].split(',');
          window.trendchart.data.labels.push(cell_data[0]);  
          for(i=1;i<cell_data.length;i++){
            window.trendchart.data.datasets[i-1].data.push(cell_data[i]);}}
    window.trendchart.update();}
function dosingXls() {	
  var rcpSel=""
  if (document.getElementById("rcpSelect")) {
    if (document.getElementById("filter").checked==true) rcpSel=document.getElementById("rcpSelect").value};
  url ='/Dosing/X?Lang=&rcpSel='+rcpSel; 
  url+='&QueryDate='+document.getElementById("QueryDate").value;
  url+='&QueryDate2='+document.getElementById("QueryDate2").value; 
  fetch(url).then(function(response){return response.text();}).then(function(resp){   
    downloadxls(resp);}); }
function batchClicked(dt,lang) { seldt=dt;//for xls
  url='/DosingBatch/0?QueryDate='+dt+'&Lang='+lang;
  htmx.ajax('GET', url, {target: '#batchtable'});
  modal.showModal();}
function dosingBatchXls() {	
  url='/DosingBatch/1?QueryDate='+seldt+'&Lang='
  fetch(url).then(function(response){return response.text();}).then(function(resp){   
    downloadxls(resp);}); }
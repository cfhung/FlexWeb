const queryString = window.location.search.substring(1);
const params = new URLSearchParams(queryString);rep=params.get("rep");
if (rep!=null){document.getElementById('rep').value=rep; }
document.addEventListener("htmx:afterSwap",function(event){if(event.detail.elt.id ==="table"){ 
  var trenddatas=document.getElementById('myTrend').innerHTML;var trendData=trenddatas.split('@@');
  updateChart(trendData[0],trendData[1]);} });
function updateChart(Labels,Datas) {  
    var labels = Labels.split(',');tLen=labels.length;
    var colors = [ "blue","red","green","BlueViolet","yellow","purple","orange","Aqua","Chartreuse","Chocolate" ];
    var canvas = document.getElementById("TrendChart");
    var ctx = canvas.getContext('2d');
    const dpi = window.devicePixelRatio || 1;const displayWidth = 1200;const displayHeight = 600;
    canvas.style.width = displayWidth + "px"; canvas.style.height = displayHeight + "px";
    canvas.width = displayWidth * dpi; canvas.height = displayHeight * dpi; ctx.scale(dpi, dpi);
    if (window.trendchart) {window.trendchart.destroy(); }
    window.trendchart = new Chart(ctx, {
      type: 'line',
      data: { labels: []},
      options:{tooltips:{mode:'index',intersect:false},scales:{ yAxes:[{ display:true, ticks:{min:0,suggestedMax:10} }] }}
      });
      var lines=[];for (i=0;i<tLen;i++){
        var line={label:labels[i],data: [],pointRadius:1,fill: false, borderColor: colors[i % 10], borderWidth: 1 };
        lines.push(line);window.trendchart.data.datasets.push(lines[i]);}    
        var rows = new Array(); rows = Datas.split(';');
        for(var count=0;count< rows.length-1; count++){
          var cell_data=rows[count].split(',');
          window.trendchart.data.labels.push(cell_data[0]);  
          for(i=1;i<cell_data.length;i++){
            window.trendchart.data.datasets[i-1].data.push(cell_data[i]);}}
    window.trendchart.update();}
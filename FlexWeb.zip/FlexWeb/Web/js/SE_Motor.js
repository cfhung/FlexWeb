document.addEventListener("htmx:afterSwap",function(event){if(event.detail.elt.id ==="table"){ 
    document.getElementById('listtable').innerHTML="" }});
function rowClicked(row) { 
    var csv=document.getElementById('myDiv').innerHTML;
    var rows = csv.split('@@');     
    var datas=rows[row].split(';'); let position = rows[row].indexOf(';');  
    updateMotorChart(datas[0],rows[row].slice(position+1)) ;  
    var s='<table class="table table-striped" style="font-size: 16px;" id="list">';
    s+="<thead><tr><td colspan='2'>"+datas[0]+"</td></tr>";
    s+="<tr><td>時間</td><td>狀態</td></tr></thead><tbody>"    
    for(var c=1;c< datas.length-1 ; c++){ var data=datas[c].split(',');  
      s+='<tr><td>'+data[0]+'</td><td>'+data[1]+'</td></tr>';}
    s+='</tbody></table>';
    s+="<input type='button' value='印表' onclick=\"printTable('list')\"/>"
    s+="<input type='button' value='趨勢圖' onclick='modal.showModal()' />"
    document.getElementById('listtable').innerHTML=s; } 
function updateMotorChart(Labels,Datas) { 
    var labels = Labels.split(',');tLen=labels.length;
    var colors = [ "blue","red","green","BlueViolet","yellow","purple","orange","Aqua","Chartreuse","Chocolate" ];
    var canvas = document.getElementById("TrendChart");
    var ctx = canvas.getContext('2d');
    const dpi = window.devicePixelRatio || 1;const displayWidth = 1200;const displayHeight = 400;
    canvas.style.width = displayWidth + "px"; canvas.style.height = displayHeight + "px";
    canvas.width = displayWidth * dpi; canvas.height = displayHeight * dpi; ctx.scale(dpi, dpi);
    if (window.trendchart) {window.trendchart.destroy(); }
    window.trendchart = new Chart(ctx, {
      type: 'line',
      data: { labels: []},
      options:{tooltips:{mode:'index',intersect:false},scales:{ 
        x: { type: 'time', time: {unit: 'hour',tooltipFormat: 'YYYY-MM-DD HH:mm:ss'},
        title: { display: true,}  },
        y: { title: { display: false,}} }}
      });
    var lines=[];for (i=0;i<tLen;i++){
    var line={label:labels[i],data: [],pointRadius:2,fill: false, borderColor: colors[i % 10], borderWidth: 2 ,stepped: true };
    lines.push(line);window.trendchart.data.datasets.push(lines[i]);}    
    var rows = new Array(); rows = Datas.split(';');
    for(var count=0;count< rows.length-1; count++){
      var cell_data=rows[count].split(',');
      window.trendchart.data.labels.push(cell_data[0]);  
      for(i=1;i<cell_data.length;i++){
      window.trendchart.data.datasets[i-1].data.push(cell_data[i]);}}
    window.trendchart.update();}   

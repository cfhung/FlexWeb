const queryString = window.location.search.substring(1);
  const params = new URLSearchParams(queryString);rep=params.get("rep");
  if (rep!=null){document.getElementById('rep').value=rep; }
document.addEventListener("htmx:afterSwap",function(event){if(event.detail.elt.id ==="table"){ 
    var bardatas=document.getElementById('myBar').innerHTML;var barData=bardatas.split(';;');
    updateBarChart(barData[0],barData[1]);} });
function updateBarChart(Data,Labels) {   
    var data=Data.split(",");var labels=Labels.split(",");
    var colors = [ "blue","red","green","BlueViolet","yellow","purple","orange","Aqua","Chartreuse","Chocolate" ];
    var canvas = document.getElementById("barChart");
    var ctx = canvas.getContext('2d');
    const dpi = window.devicePixelRatio || 1;const displayWidth = 1200;const displayHeight = 600;
    canvas.style.width = displayWidth + "px"; canvas.style.height = displayHeight + "px";
    canvas.width = displayWidth * dpi; canvas.height = displayHeight * dpi; ctx.scale(dpi, dpi);
    if (window.barchart) {window.barchart.destroy(); }
    window.barchart = new Chart(ctx, {
      type: 'bar', data: {datasets: [{label: '統計圖',borderWidth: 1 }]  },
        options:{responsive:false,scales:{ yAxes:[{ display:true, ticks:{min:0,suggestedMax:30} }] }}  });
    barchart.data.datasets[0].data=data;
    barchart.data.labels=labels;
    var backgroundColors=[];
    for (i=0;i<labels.length;i++)backgroundColors.push(colors[i %10]);
    window.barchart.data.datasets[0].backgroundColor=backgroundColors;
    window.barchart.update(); }
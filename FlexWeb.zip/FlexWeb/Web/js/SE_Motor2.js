const ctx = document.getElementById('myChart').getContext('2d');
var lb=document.getElementById('Motor').value;var labels = lb.split(',')   
const data = { labels: labels,
    datasets: [
        {   label: '運行時間',  data: [],borderWidth: 1,
            backgroundColor: 'rgba(54, 162, 235, 0.5)',borderColor: 'rgba(54, 162, 235, 1)',} ]};
const options = {
    indexAxis: 'y',
    scales: {
        x: {type: 'linear', position: 'bottom',min: 0,max: 24,
            ticks: { stepSize: 1 }, title: { display: true, text: '時間 (小時)' } },
        y: { title: { display: true, text: '設備' } }    },
    responsive: true,
    plugins: {legend: { display: false },
        tooltip: {
            callbacks: {
                label: function (context) {
                    const range = context.raw.x;
                    return `運行時間: ${timess(range[0])} ~ ${timess(range[1])}`; }
            }  }  } };
const myChart = new Chart(ctx, { type: 'bar', data: data, options: options });
document.addEventListener("htmx:afterSwap",function(event){if(event.detail.elt.id ==="table"){ 
    updatechart()}});
function updatechart() {
    const today = new Date(); const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // 月份從 0 開始
    const day = String(today.getDate()).padStart(2, '0');
    const formattedDate = `${year}-${month}-${day}`;  lastT=24;
    if (formattedDate==document.getElementById('QueryDate').value){lastT=today.getHours()+(today.getMinutes()/60)};
    var csv=document.getElementById('myDiv').innerHTML;
    var rows = csv.split('@@'); var chartData=[];
    for (var i=0;i<rows.length-1;i++){
        var datas=rows[i].split(';');
        var titles=datas[0].split('(');let title=titles[1].slice(0, -1);
        time1='00:00:00';
        for (var r=1;r<(datas.length-1);r++){
            var da=datas[r].split(',');
            if (da[1]=='1'){time1=da[0].slice(11)};
            if (da[1]=='0'){time2=da[0].slice(11);
                a=timeHours(time1);b=timeHours(time2);
                let xx = { x: [a, b], y: title };
                chartData.push(xx); }; 
            if ((r==(datas.length-2))&&(da[1]=='1')){
                a=timeHours(time1);b=lastT;
                let xx = { x: [a, b], y: title };
                chartData.push(xx);}
            }  }    
    myChart.data.datasets[0].data = chartData;
    myChart.update();
}
function rowClicked(row) {
    var csv=document.getElementById('myDiv').innerHTML;
    var rows = csv.split('@@');     
    var datas=rows[row].split(';');
    var s='<table class="table table-striped" style="font-size: 16px;" id="list">';
    s+="<thead><tr><td colspan='2'>"+datas[0]+"</td></tr>";
    s+="<tr><td>時間</td><td>狀態</td></tr></thead><tbody>"    
    for(var c=1;c< datas.length-1 ; c++){ var data=datas[c].split(',');  
    s+='<tr><td>'+data[0]+'</td><td>'+data[1]+'</td></tr>';}
    s+='</tbody></table>';
    s+="<input type='button' value='印表' onclick=\"printTable('list')\"/>";
    document.getElementById('listtable').innerHTML=s;
    modal.showModal(); } 
function timeHours(times) {
    const [h, m, s] = times.split(":").map(Number);
    return (h * 3600 + m * 60 + s)/3600; }
function timess(decimalHours) {
        let hours = Math.floor(decimalHours); 
        let minutes = Math.round((decimalHours - hours) * 60);         
        let formattedHours = String(hours).padStart(2, '0');
        let formattedMinutes = String(minutes).padStart(2, '0');        
        return `${formattedHours}:${formattedMinutes}`;
    }
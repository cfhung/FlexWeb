select DateTime,V1,V2 
From $__table()
Where DateTime between $__timeFrom() and $__timeTo()
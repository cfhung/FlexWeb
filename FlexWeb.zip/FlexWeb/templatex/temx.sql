select DateTime,V1,V2 
From Table1 
Where DateTime between $__timeFrom() and $__timeTo()
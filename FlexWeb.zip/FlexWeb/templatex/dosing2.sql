select  convert(varchar,DateTime,120)as DateTime,convert(varchar,StartTime,120)as StartTime,Recipe,RecipeDate
      ,RecipeDesc,Batch,DestBin,ABC,HandSet,HandReal,N9,Rt
From AQTG.dbo.Dosing2N 
Where DateTime between $__timeFrom() and $__timeTo()